#include "stm8s.h"

extern uint8_t oled_buffer[16][4];
void Display_Voltage(void);