#include "stm8s.h"

extern uint8_t font_regular[];