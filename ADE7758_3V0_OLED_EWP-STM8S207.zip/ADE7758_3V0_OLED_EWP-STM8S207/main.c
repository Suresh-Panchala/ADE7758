/* MAIN.C file
 * 
 * Copyright (c) 2002-2005 STMicroelectronics
 */ 
#include "stm8s.h"
#include "ade7758.h"
#include "stm8s_flash.h"
#include "usb_serial.h"
#include "OLED_f103f3.h"
#include "Flash_EEPROM.h"
#include "math.h"

float Volt_A = 0;
float Curr_A = 0;
double Pow_A = 0;
float Ener_A = 0;
bool EnergyFlag = FALSE, DisplayFlag = FALSE;
uint32_t V_Register[3], I_Register[3];
int32_t WattHR_Register[3], VAHR_Register[3], VARHR_Register[3];
uint8_t OneSec = 0;

void TIM1_setup(void)
{
  TIM1_DeInit();
  CLK_PeripheralClockConfig(CLK_PERIPHERAL_TIMER1, ENABLE);
  TIM1_TimeBaseInit(48000, TIM1_COUNTERMODE_UP, 500, 0);
  TIM1_ClearITPendingBit(TIM1_IT_UPDATE);
  TIM1_ClearFlag(TIM1_FLAG_UPDATE);
  TIM1_Cmd(ENABLE);
  TIM1_ITConfig(TIM1_IT_UPDATE, ENABLE);
  enableInterrupts();
}
void CLK_Config(void)
{
  CLK_DeInit();
  /* Configure the Fcpu to DIV1*/
  CLK_SYSCLKConfig(CLK_PRESCALER_CPUDIV1);
  /* Configure the HSI prescaler to the optimal value */
  CLK_SYSCLKConfig(CLK_PRESCALER_HSIDIV1);
  /* Configure the system clock to use HSE clock source and to run at 24Mhz */
  CLK_ClockSwitchConfig(CLK_SWITCHMODE_AUTO, CLK_SOURCE_HSE, DISABLE, CLK_CURRENTCLOCKSTATE_DISABLE);
  /* Enable CCS */
  CLK_ClockSecuritySystemEnable();
}
void Display_Window(void)
{
  OLED_print_string(0,2, "A:");
  OLED_print_string(0,4, "A:");
  OLED_print_string(0,6, "A:");
  OLED_print_string(0,0, "   V I P   ");
  OLED_print_float(24, 2, Volt_A, 1);
  OLED_print_float(24, 4, Curr_A, 3);
  OLED_print_float(24, 6, Pow_A, 3);
}
void Read_ADE7758(void)
{
  Volt_A = (float)(V_Register[0]/3923.19);
  Volt_A = (Volt_A < 20) ? 0.0: (Volt_A>400)?0:Volt_A;
  Curr_A = (float)(I_Register[0]/142600.0);
  Curr_A = (Curr_A < 0.04) ? 0.0: Curr_A;
  Pow_A = (double)WattHR_Register[0]/11217.5;
  Pow_A = (fabs(Pow_A) < 0.005) ? 0.0: Pow_A;
}
void Calibrate_ADE7758(void)
{
  setOpMode(0x00); // All HPF in Current Channels are Disabled, LPF2's are disabled, Frequency output is enabled
  gainSetup(INTEGRATOR_OFF,FULLSCALESELECT_0_5V,GAIN_1,GAIN_4); // Voltage gain 1, Current gain 4
  setupDivs(1,1,1); //Divider of the values ??that are stored in the power registers
  setLcycMode(0x0F);    // Phase A zero-crossing is used
  setLineCyc(100);
  setMaskInterrupts(ZXTOA | LENERGY | ZXA | ZXB | ZXC);
  setCompMode(0x24);    // Phase A contributes to APCF
  setAPCFNUM(0);
  setVARCFNUM(0);
  setAPCFDEN(3235);
  setVARCFDEN(3235);
  //
  setAVoltageOffset(-210);
  setBVoltageOffset(-247);
  setCVoltageOffset(-385);
  //
  setACurrentOffset(-26);
  setBCurrentOffset(-26);
  setCCurrentOffset(-26);
  //
  setAWattOffset(-10);
  //setBWattOffset(0);
  //setCWattOffset(0);
  setAWG(0);
  setBWG(0);
  setCWG(0);
  setAVARG(0);
  setBVARG(0);
  setCVARG(0);
  setAVAG(0);
  setBVAG(0);
  setCVAG(0);
  resetStatus();
}
int main(void)
{
  CLK_Config();
  Init_ADE7758();
  Calibrate_ADE7758();
  OLED_init();
  OLED_draw_logo(15,11,105,13,(uint8_t*)logo);
  delay_ms(4000);
  OLED_clear_screen();
  OLED_print_string(0,2, "   LOADING...   ");
  OLED_print_string(0,4, "              ");
  delay_ms(2000);
  OLED_clear_screen();
  TIM1_setup();
  while (1)
  {
    Read_ADE7758();
    if(DisplayFlag)
      Display_Window();
  }
}
INTERRUPT_HANDLER(EXTI_PORTC_IRQHandler, 5)
{
  uint32_t ADE7758_Status;
  if((GPIO_ReadInputData(IRQ_PORT) & IRQ_PIN) == 0x00)
  {
    if((GPIO_ReadOutputData(AFECS_PORT) & AFECS))
    {
      ADE7758_Status = resetStatus();
      setMaskInterrupts(0);
      if(ADE7758_Status & ZXTOA)
      {
        V_Register[0] = 0;
        I_Register[0] = 0;
        WattHR_Register[0] = 0;
      }
      if(ADE7758_Status & ZXTOB)
      {
        V_Register[1] = 0;
        I_Register[1] = 0;
        WattHR_Register[1] = 0;
      }
      if(ADE7758_Status & ZXTOC)
      {
        V_Register[2] = 0;
        I_Register[2] = 0;
        WattHR_Register[2] = 0;
      }
      if(ADE7758_Status & LENERGY)
      {
        WattHR_Register[0] = getWatt(PHASE_A);
        VARHR_Register[0] = getVar(PHASE_A);
        VAHR_Register[0] = getVa(PHASE_A);
        EnergyFlag = TRUE;
      }
      if(ADE7758_Status & ZXA)
      {
        V_Register[0] = read24(AVRMS);
        I_Register[0] = read24(AIRMS);
      }
      if(ADE7758_Status & ZXB)
      {
        V_Register[1] = read24(BVRMS);
        I_Register[1] = read24(BIRMS);
      }
      if(ADE7758_Status & ZXC)
      {
        V_Register[2] = read24(CVRMS);
        I_Register[2] = read24(CIRMS);
      }
    }
  }
  setMaskInterrupts(ZXTOA | LENERGY | ZXA | ZXB | ZXC);
}
INTERRUPT_HANDLER(TIM1_UPD_OVF_TRG_BRK_IRQHandler, 11)
{
  TIM1_ClearFlag(TIM1_FLAG_UPDATE);
  Ener_A += Pow_A/3600;
  OneSec++;
  DisplayFlag ^= TRUE;
}
#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *   where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{
  /* Infinite loop */
  while (1)
  {
  }
}
#endif
